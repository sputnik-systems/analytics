import requests
import time
import requests
import time
import os
import datetime
import boto3
import pytz
from dateutil.relativedelta import relativedelta
import pandas as pd

FOLDER_ID = os.getenv("FOLDER_ID") # id каталога из которого береться запрос
FOLDER = os.getenv("FOLDER") #имя папки в которую будет выкладываться
ACCESS_KEY = os.getenv("ACCESS_KEY") #aws_access_key_id для S3
SECRET_KEY = os.getenv("SECRET_KEY") #aws_secret_access_key в s3
BUCKET_NAME = os.getenv("BUCKET_NAME") #имя бакета
TIME_ZONE = os.getenv("TIME_ZONE", "Europe/Moscow") #настройка функции
TEMP_FILENAME = "/tmp/temp_file"
# URL_ALERT = os.getenv("URL_ALERT") # Ссылка для алерта для отслеживания. 
type_of_empty_values = os.getenv("type_of_empty_values")
if type_of_empty_values == 'None':
    type_of_empty_values = None
if type_of_empty_values == '':
    type_of_empty_values = ''

from Dowloading_from_query import Dowloading_from_query

def get_now_datetime_str(): # получаем актуальное время
        time_zone = os.getenv("TIME_ZONE", "Europe/Moscow") # меняем таймзону на московскую
        now = datetime.datetime.now(pytz.timezone(time_zone))    
        yesterday = now - datetime.timedelta(days=1) #нужна вчерашняя дата так как данные за прошлый день
        last_month_data = now - relativedelta(month=1)
        return {'key': yesterday.strftime('year=%Y/month=%m/%d.csv'),
                'key_month': yesterday.strftime('year=%Y/month=%m.csv'),
                'now':now.strftime('%Y-%m-%d %H:%M:%S'),
                'yesterday_data':yesterday.strftime('%Y-%m-%d'),
                'yesterday':yesterday.strftime('%Y-%m-%d %H:%M:%S'), 
                'year':yesterday.strftime('%Y'),
                'month':yesterday.strftime('%m'),
                'day':yesterday.strftime('%d'),
                'last_month_data':last_month_data.strftime('%Y-%m-%d')
                }

def get_s3_instance(): # функция создает соединение
        session = boto3.session.Session()
        return session.client(
            aws_access_key_id=ACCESS_KEY,
            aws_secret_access_key=SECRET_KEY,
            service_name='s3',
            endpoint_url='https://storage.yandexcloud.net'
        )

def upload_dump_to_s3(key): # функция выгружает данные в s3
    get_s3_instance().upload_file(
        Filename=TEMP_FILENAME,
        Bucket=BUCKET_NAME,
        Key=key
    )

def download_query_text_from_s3(): # функция выгружает данные в s3
    get_s3_instance().download_file(
        Bucket= BUCKET_NAME,
        Key=f'query_texts/{FOLDER}.txt',
        Filename='/tmp/query.txt'
    )

def download_for_query(): # функция выгружает данные в s3
    get_s3_instance().download_file(
        Bucket= BUCKET_NAME,
        Key=f'for_functions/Dowloading_from_query.py',
        Filename='/tmp/Dowloading_from_query.py'
    )
    
def remove_temp_files(): #функция удаляет временный файл
    os.remove(TEMP_FILENAME)

def parameters_def(FOLDER,i=0):
    
    date = f"{dates_pd.loc[i,'date'].strftime('%Y-%m-%d')}"
    key = f"{FOLDER}/{dates_pd.loc[i,'date_key']}"
    now = get_now_datetime_str()['now']
    query_text = open('/tmp/query.txt','r').read().format(date)
    query_name = f'{FOLDER} {now}'
    query_description = f'Ежедневный запрос- {date}'
    #headers={'Authorization':context.token['access_token'],'Accept':'application/json'}
    # headers={'Authorization':TOKEN,'Accept':'application/json'}

    return {
        'key':key,
        'date':date,
        'now':now,
        'headers':headers,
        'FOLDER_ID':FOLDER_ID,
        'query_text':query_text,
        'query_name':query_name,
        'query_description':query_description,
        'TEMP_FILENAME': TEMP_FILENAME
        }

def run(FOLDER,i):
    FOLDER = FOLDER
    i = i
    download_query_text_from_s3()
    parameters = parameters_def(FOLDER,i)
    dowloading_from_query = Dowloading_from_query()
    dowloading_from_query.get_query_parameters(parameters)
    dowloading_from_query.write_temp_file(type_of_empty_values)
    key = f"{FOLDER}/{dates_pd.loc[i,'date_key']}"
    upload_dump_to_s3(key)
    remove_temp_files()

yesterday_data = get_now_datetime_str()['yesterday_data']
start_date = datetime.datetime.strptime(yesterday_data,'%Y-%m-%d').date()
end_date = datetime.datetime.strptime(yesterday_data,'%Y-%m-%d').date()
dates_pd = pd.DataFrame({
        'date': pd.date_range(start=start_date, end=end_date),
        'date_key': pd.date_range(start=start_date, end=end_date).strftime('year=%Y/month=%m/%d.csv')
        })

dates_pd = dates_pd.iloc[::-1].reset_index(drop=True)
headers = None

def handler(event, context):
    global headers
    headers={'Authorization':context.token['access_token'],'Accept':'application/json'}
    for i in range(0,dates_pd.shape[0]):
        run(FOLDER,i)

    return {
        'statusCode': 200,
        'body': 'Hello World!',
    }